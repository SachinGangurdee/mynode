const mongoose = require('mongoose');
require('mongoose-type-email');

const empSchema = new mongoose.Schema({

    firstname:{
        type:String
    },
    middlename:{
        type:String
    },
    lasttname:{
        type:String
    },
    username:{
        type:String
    },
    password:{
        type:String
    },
    email:{
        type:mongoose.SchemaTypes.Email
    },
    mobile:{
        type:Number
    },
    address:{
        type:String
    }
})

module.exports = mongoose.model('emp',empSchema)
const express = require('express');

const router =  express.Router()
const emp = require('../models/emp')

//finding all details
router.get('/findall', async (req,res)=>{
    try{
        const empps = await emp.find()
        res.json(empps);  
    }
    catch(err){
        res.send("Error");  
    }
})

//finding particular with request parameter
router.get('/find/:firstname',async(req,res)=>{
 
    try{
       const f = await emp.find({firstname:req.params.firstname})
       res.json(f)
    }
    catch(err){
        res.send("Error"+err); 
    }
})

//updating a particular record
router.patch('/update/:name',async(req,res)=>{
    try{
        const updated = await emp.updateOne({name:req.params.name},{$set:{tech:req.body.tech}})
        res.json(updated)
    }
    catch(err){
        res.send("Error"+err);
    }
})

//deleting a particular record
router.delete('/delete/:name', async(req,res)=>{
    try{
        const deleted=await emp.remove({name:req.params.name})
        res.json(deleted)
    }catch(err){
        res.send("Error"+err);
    }
})

//inserting a employee in the database
router.post('/register',async(req,res)=>{

    const empp= new emp({
        firstname:req.body.firstname,
        middlename:req.body.middlename,
        lasttname:req.body.lasttname,
        username:req.body.username,
        password:req.body.password,
        email:req.body.email,
        mobile:req.body.mobile,
        address:req.body.address
    })

    try{
       const e = await empp.save()
       res.json(e)
    }
    catch(err){
        res.send("Error"+err); 
    }
})

//sample
router.get('/hr', async (req,res)=>{
    try{
        res.send("data received for hr");  
    }
    catch(err){
        res.send("Error");  
    }
})

module.exports = router
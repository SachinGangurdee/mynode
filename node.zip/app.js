const express = require('express');
const url='mongodb://localhost:27017/DB1'
const mongoose = require('mongoose');
const app = express()
app.use(express.json()); 
const employeeRouter = require('./routes/employees')
app.use('/',employeeRouter);

// to tell server that we are using json format


mongoose.connect(url,{useNewUrlParser : true})
const con = mongoose.connection

con.on('open',()=>{
    console.log('connected.....')
})

app.listen(9999,()=>{
    console.log('9999 Started')
})